
package org.test;

public class SoundEffect {
	
	public void Play(){
		
	}

}
