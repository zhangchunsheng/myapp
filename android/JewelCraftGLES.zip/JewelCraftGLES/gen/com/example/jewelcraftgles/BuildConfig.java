/** Automatically generated file. DO NOT MODIFY */
package com.example.jewelcraftgles;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}